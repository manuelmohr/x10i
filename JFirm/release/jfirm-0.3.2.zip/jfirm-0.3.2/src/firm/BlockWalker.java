package firm;

import firm.nodes.Block;

public interface BlockWalker {

	void visitBlock(Block block);
	
}
